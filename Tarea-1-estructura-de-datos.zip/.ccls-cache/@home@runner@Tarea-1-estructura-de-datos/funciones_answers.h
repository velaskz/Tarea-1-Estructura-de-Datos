#ifndef funciones_answers_h
#define funciones_answers_h

void mostrarOpciones();
void mostrarMenu();
void registrarLibro();
void mostrarDatosLibro();
void mostrarLibros();
void reservarLibro();
void cancelarReserva();
void retirarLibro();
void devolverLibro();
void mostrarLibrosPrestados();
void importarLibros();
void exportarLibros();

#endif // funciones_answers_h