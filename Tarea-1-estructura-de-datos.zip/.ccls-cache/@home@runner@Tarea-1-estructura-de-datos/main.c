#include <stdio.h>
#include "funciones_answers.h"

int main() {

    struct List* biblioteca = createList();
    mostrarMenu(biblioteca);

    return 0;
}